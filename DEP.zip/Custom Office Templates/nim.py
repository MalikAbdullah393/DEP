import sys

class RedBlueNimGame:
    def __init__(self, num_red, num_blue, version="standard", first_player="computer", depth=None):
        self.num_red = num_red
        self.num_blue = num_blue
        self.version = version
        self.first_player = first_player
        self.depth = depth
        self.turn = 0 if first_player == "computer" else 1  # 0: computer, 1: human

    def is_game_over(self):
        if self.version == "standard":
            return self.num_red == 0 or self.num_blue == 0
        else:  # Misère version
            return self.num_red == 0 and self.num_blue == 0

    def calculate_score(self):
        return self.num_red * 2 + self.num_blue * 3

def parse_command_line_args():
    if len(sys.argv) < 4:
        print("Usage: python nim.py <num-red> <num-blue> <version> [first-player] [depth]")
        sys.exit(1)

    num_red = int(sys.argv[1])
    num_blue = int(sys.argv[2])
    version = sys.argv[3]
    first_player = sys.argv[4] if len(sys.argv) > 4 else "computer"
    depth = int(sys.argv[5]) if len(sys.argv) > 5 else None

    return num_red, num_blue, version, first_player, depth

def play_game(game):
    while not game.is_game_over():
        if game.turn == 1:  # Human move
            human_move(game)
        else:  # Computer move
            computer_move(game)

        game.turn = 1 - game.turn  # Switch turn

    print("Game Over!")
    print(f"Final Score: {game.calculate_score()}")

def human_move(game):
    print(f"Your move: {game.num_red} red, {game.num_blue} blue")
    while True:
        try:
            red = int(input("Pick red marbles (0 if none): "))
            blue = int(input("Pick blue marbles (0 if none): "))
            if red > game.num_red or blue > game.num_blue or (red == 0 and blue == 0):
                raise ValueError("Invalid move")
            break
        except ValueError as e:
            print(e)
    
    game.num_red -= red
    game.num_blue -= blue

def computer_move(game):
    red = min(2, game.num_red)
    blue = min(2, game.num_blue)
    
    game.num_red -= red
    game.num_blue -= blue
    
    print(f"Computer picks {red} red and {blue} blue marbles.")

if __name__ == "__main__":
    num_red, num_blue, version, first_player, depth = parse_command_line_args()
    game = RedBlueNimGame(num_red, num_blue, version, first_player, depth)
    play_game(game)
